﻿namespace KsqlDsl.Configuration.Abstractions;


public enum ValidationMode
{
    Strict,

    Relaxed
}
