using System;

namespace KsqlDsl.Core.Modeling;
[AttributeUsage(AttributeTargets.Property)]
public class DateTimeFormatAttribute : Attribute
{
    public string Format { get; set; }
    public string? Region { get; set; }

}
