﻿namespace KsqlDsl.Query.Abstructions;

internal enum StreamTableType
{
    Stream,
    Table
}
