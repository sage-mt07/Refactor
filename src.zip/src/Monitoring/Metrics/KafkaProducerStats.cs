﻿using System;

namespace KsqlDsl.Monitoring.Metrics
{
    // =============================================================================
    // Statistics & Health Classes - 統計・ヘルス情報
    // =============================================================================

    /// <summary>
    /// Producer統計情報
    /// </summary>
    public class KafkaProducerStats
    {
        public long TotalMessagesSent { get; set; }
        public long SuccessfulMessages { get; set; }
        public long FailedMessages { get; set; }
        public double SuccessRate => TotalMessagesSent > 0 ? (double)SuccessfulMessages / TotalMessagesSent : 0;
        public TimeSpan AverageLatency { get; set; }
        public TimeSpan MinLatency { get; set; }
        public TimeSpan MaxLatency { get; set; }
        public DateTime LastMessageSent { get; set; }
        public long TotalBytesSent { get; set; }
        public double MessagesPerSecond { get; set; }
    }


}
