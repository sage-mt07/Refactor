﻿namespace KsqlDsl.Monitoring.Abstractions
{
    public enum CacheIssueSeverity
    {
        Low,
        Medium,
        High,
        Critical
    }

}
