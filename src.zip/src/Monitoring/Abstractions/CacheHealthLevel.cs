﻿namespace KsqlDsl.Monitoring.Abstractions
{
    public enum CacheHealthLevel
    {
        Healthy,
        Warning,
        Critical
    }
}
